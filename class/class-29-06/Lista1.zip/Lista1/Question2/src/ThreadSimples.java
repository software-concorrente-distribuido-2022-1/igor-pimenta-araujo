public class ThreadSimples extends Thread {
    public void run() {
        System.out.println("Hello from a thread!");
    }
}