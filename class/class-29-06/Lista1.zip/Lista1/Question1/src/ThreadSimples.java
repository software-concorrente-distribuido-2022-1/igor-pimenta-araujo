public class ThreadSimples implements Runnable {
    public void run() {
        System.out.println("Olá de uma thread!");
    }

}