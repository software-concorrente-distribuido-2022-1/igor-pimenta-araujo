public class Tela {
    // Recurso disputado
    String texto;

    public void setTexto(String s) {
        texto = s;
    }

    public void mostraTexto() {
        System.out.println(texto);
    }
}