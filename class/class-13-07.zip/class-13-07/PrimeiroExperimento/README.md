## Relatorio

- Felipe
- Igor 
- Mozaniel

## Primeiro Experimento

Entrada de dados: Usuario 1, Usuario 2, Usuario 3, Usuario 4.
Saida de dados: 
```
Usuario 02
Usuario 02
Usuario 02
Usuario 02
Usuario 02
Usuario 04
Usuario 04
Usuario 02
Usuario 01
Usuario 04
Usuario 03
Usuario 03
Usuario 01
Usuario 01
Usuario 01
Usuario 04
Usuario 01
Usuario 01
Usuario 01
Usuario 01
```

Problema: Os usuarios deveriam aparecer cinco vezes cada, mas aparecem indefinidamente. 

## Segundo Experimento

Entrada de dados: Usuario 1, Usuario 2, Usuario 3, Usuario 4