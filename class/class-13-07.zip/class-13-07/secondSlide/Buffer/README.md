## Relatorio

Alunos:
- Felipe Kafuri
- Igor 
- Mozaniel

Implementa uma solução produtor, consumidor, buffer limitado para um buffer pequeno .
Usando metodos de entrada e saida, implementando exclusão mutua por conta da região crítica(buffer) e coordenação porque não podemos ler se o recurso estiver vazio e nao pode gravar se estiver cheio.