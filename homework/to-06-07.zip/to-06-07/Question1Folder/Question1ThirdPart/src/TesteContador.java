public class TesteContador {
    public static void main(String[] args) throws Exception {
        Contador c1 = new Contador();
        Contador c2 = new Contador();
        Contador c3 = new Contador();

        c1.start();
        c2.start();
        c3.start();
    }
}
