## 2.3

- Além da sincronização, é importante permitir a coordenação entre as threads. Os métodos
utilizados são wait(), notify() e notifyAll(). Utilizando estes métodos, altere a implementação do
sistema para permitir uma coordenação adequada entre os objetos.